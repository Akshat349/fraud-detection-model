import pandas as pd
import os
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import IsolationForest
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay, classification_report

pd.set_option('display.max_rows', None)
pd.set_option('display.max_columns', None)
pd.set_option('display.width', None)
pd.set_option('display.max_colwidth', None)

def evaluate_model(true, pred):
    cm = confusion_matrix(true, pred)
    tn, fp, fn, tp = cm.ravel()
    precision = tp / (tp + fp) if (tp + fp) != 0 else 0
    recall = tp / (tp + fn) if (tp + fn) != 0 else 0
    f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) != 0 else 0
    return pd.DataFrame({
        'Metric': ['True Positives', 'True Negatives', 'False Positives', 'False Negatives', 'Precision', 'Recall', 'F1 Score'],
        'Value': [tp, tn, fp, fn, precision, recall, f1]
    })

def detect_fraudulent_claims(fraudulent_claims_full_details):
    # Load and clean the main claims data
    fraud_claim = pd.read_csv(fraudulent_claims_full_details, encoding='ISO-8859-1')
    claims = fraud_claim.drop_duplicates(subset=['Claim No.', 'Claim Type'], keep='first').copy()

    # Create new feature flags based on rules
    claims['invalid_claim_no'] = claims['Claim No.'].isnull() | (claims['Claim No.'] == '')
    claims['irregular_service_dealer_code'] = claims['vehicle Service dealer code'].astype(str).str.contains(r'[^a-zA-Z0-9]', regex=True, na=False)
    claims['irregular_selling_dealer_code'] = claims['Vehicle Selling Dealer no'].astype(str).str.contains(r'[^a-zA-Z0-9]', regex=True, na=False)

    # Convert dates with explicit format to avoid warnings
    claims['date_of_vehicle_sale'] = pd.to_datetime(claims['Date of vehicle Sale'], errors='coerce', format='%d-%m-%Y')
    claims['vehicle_age'] = (pd.Timestamp.today() - claims['date_of_vehicle_sale']).dt.days // 365
    claims['invalid_vehicle_age'] = claims['vehicle_age'] > 20

    claims['repair_date'] = pd.to_datetime(claims['Repair Dat'], errors='coerce', format='%d-%m-%Y')
    claims['invalid_repair_date'] = claims['repair_date'] > pd.Timestamp.today()

    claims['invalid_distance'] = claims['Distance'] > 350000

    claims['mfg_date'] = pd.to_datetime(claims['Date of vehicle Sale'], errors='coerce', format='%d-%m-%Y')
    claims['invalid_mfg_date'] = claims['mfg_date'] > pd.Timestamp.today()

    claims['suspicious_chassis_match'] = (
        (claims.groupby('Chassis no')['Vehicle Type'].transform('nunique') > 1) |
        (claims.groupby('Chassis no')['Model Description'].transform('nunique') > 1)
    )

    claims['high_claim_foreign_currency'] = claims['Currncy'].astype(str).str.upper() != 'INR'
    claims['reg_no_multiple_vehicle_types'] = claims.groupby('Registration No')['Vehicle Type'].transform('nunique') > 1
    claims['Suspicion_cost'] = claims['Material cost'] > 100000
    duplicate_registration = claims['Registration No'].value_counts()
    suspicious_registration = duplicate_registration[duplicate_registration > 2].index
    claims['duplicate_registration'] = claims['Registration No'].isin(suspicious_registration)
    claims['missing_customer_name'] = claims['Customer Name'].astype(str).str.strip().str.len() < 3
    claims['Suspicious Quantity'] = claims['Quantity'] > 3

    # Combine all rules into a single flag
    claims['rule_based_suspicious'] = (
        claims['invalid_claim_no'] |
        claims['irregular_service_dealer_code'] |
        claims['irregular_selling_dealer_code'] |
        claims['invalid_vehicle_age'] |
        claims['invalid_repair_date'] |
        claims['invalid_distance'] |
        claims['invalid_mfg_date'] |
        claims['suspicious_chassis_match'] |
        claims['duplicate_registration'] |
        claims['missing_customer_name'] |
        claims['reg_no_multiple_vehicle_types'] |
        claims['Suspicious Quantity'] |
        claims['Suspicion_cost'] |
        claims['high_claim_foreign_currency']
    )
    
    # Isolation Forest for anomaly detection
    feature_cols = [
        'Quantity',
        'vehicle_age',
        'invalid_claim_no',
        'invalid_distance',
        'Suspicion_cost',
        'duplicate_registration'
    ]
    features = claims[feature_cols].fillna(0)
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)
    iso_forest = IsolationForest(contamination=0.05, random_state=45)
    iso_forest.fit(features_scaled)

    claims['isolation_forest_anomaly'] = iso_forest.predict(features_scaled)
    claims['isolation_forest_anomaly'] = claims['isolation_forest_anomaly'] == -1
    claims['final_suspicious'] = claims['rule_based_suspicious'] | claims['isolation_forest_anomaly']

    # Function to get reasons for flagging
    def get_reason(row):
        reasons = []
        if row['invalid_claim_no']:
            reasons.append('Invalid claim number')
        if row['irregular_service_dealer_code']:
            reasons.append('Irregular Service Dealer Code')
        if row['irregular_selling_dealer_code']:
            reasons.append('Irregular Selling Dealer Code')
        if row['invalid_vehicle_age']:
            reasons.append('Vehicle age exceeds 15 years')
        if row['invalid_repair_date']:
            reasons.append('Repair date is in the future')
        if row['invalid_distance']:
            reasons.append('Distance exceeds 3,50,000 km')
        if row['invalid_mfg_date']:
            reasons.append('MFG Date is in the future')
        if row['suspicious_chassis_match']:
            reasons.append('Duplicate chassis no in registration no, vehicle type, model')
        if row['duplicate_registration']:
            reasons.append('Duplicate registration number for more than two vehicles')
        if row['Suspicion_cost']:
            reasons.append('Service_cost_exeed_validate_amont_of 200000')
        if row['missing_customer_name']:
            reasons.append('Suspicious_name')
        if row['high_claim_foreign_currency']:
            reasons.append('invalid_currency')
        if row['Suspicious Quantity']:
            reasons.append('Quantity exceed limit')
        if row['reg_no_multiple_vehicle_types']:
            reasons.append('Multiple registration no append')
        if row['isolation_forest_anomaly']:
            reasons.append('Irregular patterns detected by Isolation Forest')
        return ', '.join(reasons) if reasons else ' irregular pattern '

    claims['Reason_for_False_Claim'] = claims.apply(get_reason, axis=1)
    suspicious_claims = claims[claims['final_suspicious']]

    # Consolidate directory creation
    output_viz_folder = r'C:\Users\akshat\Django\Fraud Detection\output\visual_output'
    output_csv_folder = r'C:\Users\akshat\Django\Fraud Detection\output\csv'
    output_xlsx_folder = r'C:\Users\akshat\Django\Fraud Detection\output\excle'
    os.makedirs(output_viz_folder, exist_ok=True)
    os.makedirs(output_csv_folder, exist_ok=True)
    os.makedirs(output_xlsx_folder, exist_ok=True)

    # Visualizations
    plt.figure(figsize=(12, 6))
    sns.barplot(x=['False Claims', 'Total Claims'],
                y=[suspicious_claims['Material cost'].sum(), claims['Material cost'].sum()], hue=['False Claims', 'Total Claims'], palette='Set2', legend=False)
    plt.title('Material cost Comparison: False Claims vs Total Claims (Bar Chart)')
    plt.xlabel('Claim Type')
    plt.ylabel('Total Material cost')
    plt.savefig(os.path.join(output_viz_folder, 'claim_cost_comparison_bar.png'))
    plt.close()

    plt.figure(figsize=(8, 8))
    claims['final_suspicious'].value_counts().plot.pie(
        autopct='%1.1f%%',
        colors=['#ff9999', '#66b3ff'],
        startangle=90,
        wedgeprops={'edgecolor': 'black'}
    )
    plt.title('Suspicious vs Non-Suspicious Claims (Pie Chart)')
    plt.ylabel('')
    plt.savefig(os.path.join(output_viz_folder, 'suspicious_vs_non_suspicious_pie.png'))
    plt.close()

    plt.figure(figsize=(16, 16))
    colors = ['#66b3ff', '#ff9999']
    wedgeprops = {'edgecolor': 'black', 'width': 0.3}
    total_claims_count = len(claims)
    fraudulent_claims_count = len(suspicious_claims)

    plt.subplot(2, 2, 1)
    plt.pie([total_claims_count, fraudulent_claims_count],
            labels=['Quantity', 'Suspicious Quantity'],
            autopct='%1.1f%%', startangle=90,
            colors=colors, wedgeprops=wedgeprops)
    plt.title('Total Quantity vs Suspicious Quantity (Donut Chart)')

    plt.subplot(2, 2, 2)
    plt.pie([total_claims_count, fraudulent_claims_count],
            labels=['Total Claims', 'Fraudulent Claims'],
            autopct='%1.1f%%', startangle=90,
            colors=colors, wedgeprops=wedgeprops)
    plt.title('Total Claims vs Fraudulent Claims (Donut Chart)')

    plt.subplot(2, 2, 3)
    suspicious_material_cost = claims[claims['Suspicion_cost']]['Material cost'].sum()
    plt.pie([claims['Material cost'].sum(), suspicious_material_cost],
            labels=['Material cost', 'Suspicion cost'],
            autopct='%1.1f%%', startangle=90,
            colors=colors, wedgeprops=wedgeprops)
    plt.title('Total Claims vs Fraudulent Material Cost (Donut Chart)')

    plt.subplot(2, 2, 4)
    invalid_distance_count = claims['invalid_distance'].sum()
    plt.pie([total_claims_count, invalid_distance_count],
            labels=['Distance', 'Invalid Distance'],
            autopct='%1.1f%%', startangle=90,
            colors=colors, wedgeprops=wedgeprops)
    plt.title('Total Claims vs Fraudulent Distance (Donut Chart)')
    plt.tight_layout()
    plt.savefig(os.path.join(output_viz_folder, 'combined_donut_charts.png'))
    plt.close()

    # Confusion Matrix and Evaluation
    y_true = claims['rule_based_suspicious'].astype(int)
    y_pred = claims['final_suspicious'].astype(int)
    cm = confusion_matrix(y_true, y_pred)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Genuine", "Fraud"])
    plt.figure(figsize=(8, 6))
    disp.plot(cmap='Blues', values_format='d')
    plt.title('Confusion Matrix (Rule-Based vs Isolation Forest)')
    plt.savefig(os.path.join(output_viz_folder, 'confusion_matrix.png'))
    plt.close()

    print("=" * 89, "Beggining Of Output", "=" * 89)
    print("\nClassification Report:\n")
    print(classification_report(y_true, y_pred, target_names=["Genuine", "Fraud"]))
    print("=" * 200)
    print("\n confusion_matrix")
    print(confusion_matrix(y_true, y_pred))
    print("=" * 200)
    eval_df = evaluate_model(y_true, y_pred)
    print("\nEvaluation Summary:\n")
    print(eval_df)

    return claims, suspicious_claims

full_claims, suspicious_claims = detect_fraudulent_claims('fraudulent_claims_full_details.csv')

print("=" * 200)
print("Total Claims:", len(full_claims))
print("Suspicious Claims Detected:", len(suspicious_claims))

output_csv_folder = r'C:\Users\akshat\Django\Fraud Detection\output\csv'
output_xlsx_folder = r'C:\Users\akshat\Django\Fraud Detection\output\excle'

# Save all claims and suspicious claims
full_claims.to_csv(os.path.join(output_csv_folder, 'all_claims_with_flags.csv'), index=False)
suspicious_claims.to_csv(os.path.join(output_csv_folder, 'false_claims_list.csv'), index=False)
suspicious_claims.to_excel(os.path.join(output_xlsx_folder, 'false_claims_list.xlsx'), index=False)

print("=" * 200)
print("Suspicious (False) Claims Detected:\n")
print(suspicious_claims[['Claim No.', 'vehicle Service dealer code', 'Currncy', 'Vehicle Selling Dealer no', 'Chassis no', 'Date of vehicle Sale', 'Repair Dat', 'Material cost', 'Distance', 'Reason_for_False_Claim']])
print("=" * 200)
print("False claims saved to false_claims_list.csv and false_claims_list.xlsx")
print("=" * 90, "End Of Output", "=" * 90)